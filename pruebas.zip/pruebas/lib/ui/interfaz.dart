import 'package:flutter/material.dart';
import '../logica/multiplo.dart';

class Interfaz extends StatefulWidget {
  @override
  _InterfazState createState() => _InterfazState();
}

class _InterfazState extends State<Interfaz> {
  final Multiplo _multiplo = Multiplo();
  int? _numero;
  String _resultado = "Presiona el botón para generar un número";
  Color _colorResultado = Colors.black;

  void _verificarNumero() {
    setState(() {
      _numero = _multiplo.generarNumero();
      if (_multiplo.esMultiploYEnRango(_numero!)) {
        _resultado = "✅ Correcto";
        _colorResultado = Colors.green;
      } else {
        _resultado = "❌ Incorrecto";
        _colorResultado = Colors.red;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.check_circle, color: Colors.white),
            SizedBox(width: 8),
            Text(
              "Verificador de Números",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
        backgroundColor: Colors.green,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.network(
                'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQsVFSqbF7n79uSZNX7yYJeBmBeL4HgeiKudA&s',
                height: 150,
                width: 150,
              ),
              SizedBox(height: 20),
              Icon(
                Icons.numbers,
                size: 75,
                color: Colors.green,
              ),
              SizedBox(height: 20),
              if (_numero != null)
                Text(
                  "Número: $_numero",
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.green,
                  ),
                ),
              if (_numero != null) SizedBox(height: 10),
              Text(
                _resultado,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: _colorResultado,
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _verificarNumero,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                ),
                child: Text(
                  "Generar Número",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
