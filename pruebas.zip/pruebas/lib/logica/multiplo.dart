import 'dart:math';

class Multiplo {
  int generarNumero() {
    final random = Random();
    return random.nextInt(1000) + 1;
  }

  bool esMultiploYEnRango(int numero) {
    return numero % 5 == 0 && numero <= 25;
  }
}
