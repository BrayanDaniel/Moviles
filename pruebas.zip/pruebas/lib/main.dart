import 'package:flutter/material.dart';
import 'ui/interfaz.dart';

void main() {
  runApp(MaterialApp(
    home: Interfaz(),
    debugShowCheckedModeBanner: false,
  ));
}
